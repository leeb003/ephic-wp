<?php
/**
  * Register custom post types used in our plugin, Projects
  */

    class Ephic_Register_Posts {
        // properties

        // methods
        public function __construct() {
            //add_action('init', array($this, 'register_posts'));

		}

		public function register_posts() {
            // projects
            $project_labels = array(
                'name'               => __('Project Item', 'ephic-plugin'),
                'menu_name'          => __('Project Entries', 'ephic-plugin'),
                'add_new'            => __('Add new', 'ephic-plugin'),
                'add_new_item'       => __('Add New Project Entry', 'ephic-plugin'),
                'edit_item'          => __('Edit Project Entry', 'ephic-plugin'),
                'new_item'           => __('New Project Entry', 'ephic-plugin'),
                'view_item'          => __('View Project Entry', 'ephic-plugin'),
                'search_items'       => __('Search Projects', 'ephic-plugin'),
                'not_found'          => __('No Project Entries Found', 'ephic-plugin'),
                'not_found_in_trash' => __('No Project Entries found in Trash', 'ephic-plugin'),
                'parent_item_colon'  => ''
            );

            $project_args = array(
                'labels'             => $project_labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'query_var'          => true,
                'rewrite'            => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'capability_type'    => 'post',
                'taxonomies'         => array('project_entry'),
                'supports'           => array('title', 'editor', 'thumbnail', 'author', 'comments' ),
                'exclude_from_search'=> true,
                'menu_icon'          => 'dashicons-grid-view'
            );

            register_post_type('project_entry', $project_args);

            // register the custom project taxonomy
            register_taxonomy('ephic_projectcat',
                'project_entry',
                array(
                    'label' => __('Project Category', 'ephic-plugin'),
                    'rewrite' => array(),
                    'capabilities' => array(),
					'show_admin_column' => true,
                )
            );
        }
	} // end class
