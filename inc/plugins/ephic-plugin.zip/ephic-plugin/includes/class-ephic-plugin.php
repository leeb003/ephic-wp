<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Plugin_Name
 * @subpackage Plugin_Name/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Plugin_Name
 * @subpackage Plugin_Name/includes
 * @author     Your Name <email@example.com>
 */
class EPHIC_Plugin {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Plugin_Name_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $ephic_plugin    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		$this->plugin_name = 'ephic-plugin';
		$this->version = '1.0.0';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Plugin_Name_Loader. Orchestrates the hooks of the plugin.
	 * - Plugin_Name_i18n. Defines internationalization functionality.
	 * - Plugin_Name_Admin. Defines all hooks for the admin area.
	 * - Plugin_Name_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-plugin-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-plugin-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-ephic-plugin-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-ephic-plugin-public.php';

		$this->loader = new EPHIC_Plugin_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Plugin_Name_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new EPHIC_Plugin_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new EPHIC_Plugin_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		/* Register our custom post types included with the plugin */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-register-posts.php';
		$ephic_register_posts = new Ephic_Register_Posts();
		$this->loader->add_action( 'init', $ephic_register_posts, 'register_posts' );

		/* Register our custom widgets included with the plugin */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-widget-recent-posts.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-widget-tag-cloud.php';
		add_action( 'widgets_init', array($this, 'ephic_register_custom_widgets') );

		/* Theme import demo admin ajax */
        add_action('wp_ajax_import_demo_content', array(&$this, "import_demo_content") );

		/**
         * Include our demo import admin page
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-theme-import-admin.php';
        new ephic_theme_import_admin();
	}

	/**
     * Register all of the widgets included with the plugin
     * 
     * @since    1.0.0
     * @access   public
     */
    public function ephic_register_custom_widgets() {
		register_widget( 'EPHIC_Widget_Recent_Posts' );
        register_widget( 'EPHIC_Widget_Tag_Cloud' );
	}

	/**
	 * Import demo content
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function import_demo_content() {
        if (!wp_verify_nonce( $_POST['nonce'], "import_demo_content")) {
            exit("Invalid Request");
        }

        $demo_choice = intval($_POST['demo_choice']);
        // 1 is Main
        if (!class_exists("WP_Import")) {
            if (!defined("WP_LOAD_IMPORTERS")) define("WP_LOAD_IMPORTERS",true);
            require_once(plugin_dir_path( dirname( __FILE__ ) ) . 'includes/importer/wordpress-importer.php');
        }
        require_once(plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ephic-theme-import.php');

        $this->importer = new ephic_import();
        $this->importer->fetch_attachments = true;

        $response = $this->importer->getDemo($demo_choice);

        $jsonData = array (
            'type'            => 'success',
            'success'         => $this->importer->success,
            'options_success' => $this->importer->options_success,
            'response'        => $this->importer->response
        );
        echo json_encode($jsonData);
        die();
    }


	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new EPHIC_Plugin_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Plugin_Name_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
